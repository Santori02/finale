import UIKit

class RegViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }
    



}
